<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "register";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve updated user information from the form
    $user_id = $_POST['user_id'];
    $workinghours = $_POST['workinghours'];

    // Update user information in the database
    $sql = "UPDATE users SET workinghours='$workinghours' WHERE id=$user_id";

    if ($conn->query($sql) === TRUE) {
        // Redirect back to the profile page after updating
        header("Location: profile.php");
        exit();
    } else {
        echo "Error updating profile: " . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>