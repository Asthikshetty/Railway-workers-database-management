<?php
// Start the session
session_start();

// Unset all session variables
$_SESSION = [];

// Destroy the session
session_destroy();

// Redirect to main1.html after logout
header("Location: index.html");

// Ensure that the script stops execution after redirection
exit;
?>
