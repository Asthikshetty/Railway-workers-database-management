<?php
// Database configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "register";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process login form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST["adminid"]);
    $password = $_POST["password"];

    // Retrieve user data from the database
    $sql = "SELECT * FROM admin WHERE adminid = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();

        // Verify the password
        if ($row['password'] === $password) {
            // Start a session and store user information
            session_start();
            $_SESSION["adminid"] = $row["adminid"];

            // Redirect to the user profile page
            header("Location: admin.php");
            exit();
        } else {
            echo "Invalid password";
        }
    } else {
        echo "User not found";
    }
}

// Close the database connection
$conn->close();
?>