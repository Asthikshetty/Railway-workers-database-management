<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        p{
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            font-weight:bold;
        }
        body {
            font-family: Arial, sans-serif;
            background-image: url('https://images.unsplash.com/photo-1579546929516-fc26fc197db2');
            background-size: cover;
            background-position: center;
            margin: 0;
            padding: 0;
            color: white;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: rgba(0, 0, 0, 0.7);
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            position: relative;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            color: white;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #333;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #555;
        }

        tr:hover {
            background-color: #444;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

        .header h1 {
            font-size: 32px;
            font-weight: bold;
            text-transform: uppercase;
            margin-top: 30px;
        }

        .header h2 {
            font-size: 24px;
            font-weight: bold;
            text-transform: uppercase;
            margin-top: 10px;
        }

        .logout {
            float: right;
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            margin-top: -40px;
            margin-right: 20px;
        }

        /* .slider {
            overflow: hidden;
            white-space: nowrap;
            animation: marquee 15s linear infinite;
        }

        .slider p {
            display: inline-block;
            margin: 0;
            padding-right: 100%;
            font-size: 20px; */
        

        .search-form {
            position: absolute;
            top: 20px;
            left: 20px;
        }

        @keyframes marquee {
            0% { transform: translate(100%, 0); }
            100% { transform: translate(-100%, 0); }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Government of India</h1>
            <h2>Ministry of Railways</h2>
        </div>
        <div class="search-form">
            <form action="" method="GET">
                <input type="text" name="search" placeholder="Search by Name">
                <button type="submit">Search</button>
            </form>
        </div>
        <a href="logout.php" class="logout">Logout</a>
            <marquee behavior="" direction="">Welcome to the Indian Railways admin dashboard. Here you can view information about workers.</marquee>
        <table>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Working Hours</th>
            </tr>
            <?php
            // Database connection parameters
            $servername = "localhost"; // Change this to your database server name
            $username = "root"; // Change this to your database username
            $password = ""; // Change this to your database password
            $dbname = "register"; // Change this to your database name

            // Establishing connection to the database
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check for connection errors
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Retrieve all workers' information from the database sorted by workinghours
            $sql = "SELECT * FROM users";
            
            // If search query is present, modify the SQL query
            if(isset($_GET['search']) && !empty($_GET['search'])) {
                $search = $_GET['search'];
                $sql .= " WHERE first_name LIKE '%$search%' OR last_name LIKE '%$search%'";
            }

            $sql .= " ORDER BY workinghours ASC"; // Sorting by workinghours from lower to higher
            
            $result = $conn->query($sql);

            // Check if there are workers in the database
            if ($result->num_rows > 0) {
                // Output data of each worker
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["id"] . "</td>";
                    echo "<td>" . $row["first_name"] . "</td>";
                    echo "<td>" . $row["last_name"] . "</td>";
                    echo "<td>" . $row["email"] . "</td>";
                    echo "<td>" . $row["phone"] . "</td>";
                    echo "<td>" . $row["workinghours"] . "</td>";
                    echo "</tr>";
                }
            } else {
                // If no workers found in the database
                echo "<tr><td colspan='6'>No workers found in the database.</td></tr>";
            }

            // Close database connection
            $conn->close();
            ?>
        </table>
    </div>
</body>
</html>
