<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <title>Indian Railway</title>
  <style>
    body {
      
      margin: 0;
      padding: 0;
      background-color: #f2f2f2;
    }
h1{
  font-family:Verdana, Geneva, Tahoma, sans-serif;
      color: blue;
      background-color: white;
}
    header {
      color: #fff;
      padding: 10px;
      text-align: center;
    }

    nav {
      background-color: #ddd;
      padding: 10px;
      text-align: center;
      padding-right: 33px;
    }

    section {
      padding: 20px;
    }

    footer {
      background-color: #333;
      color: #fff;
      padding: 10px;
      text-align: center;
      position: fixed;
      bottom: 0;
      width: 100%;
      border-radius: 11px;
      height: 53px;
    }
    .carousel{
      width:100%;
    }
    .logo3{
      float:right;
      padding-left:80px;
      width: 164px;
    height: 100px;
    }
    .logo4{
      float:left;
      width: 136px;
      height:100px ;
      
    }
    .marq{
      font-family: Verdana, Geneva, Tahoma, sans-serif;
    }
    a{
      font-family: Verdana, Geneva, Tahoma, sans-serif;
      font-weight: bold;
      color: rgb(109, 102, 219);
      text-decoration: none;
    }
  </style>
</head>
<body>
  <header>
    <img src="logo.gif" alt="">
    <img class="logo3" src="logo3.png" alt="">
    <img class="logo4" src="log-4.jpg" alt="">
  </header>

  <nav >
    <div id="size">
    <a id="nav" href="home.html">Home</a> |
    <a href="https://indianrailways.gov.in/#">Ministry Of Railways</a> |
    <a href="https://indianrailways.gov.in/railwayboard/view_section.jsp?lang=0&id=0,7,1281">Recuitment</a> |
    <a href="https://www.irctc.co.in/nget/train-search">Book Tickets</a>|
    <a href="profile.php">profile </a>
  </div>
  </nav>
  <marquee class="marq">"Welcome aboard the Indian Railways family! 🚆 Register now to unlock a world of seamless travel experiences, convenient bookings, and exciting offers tailored just for you. Let's embark on unforgettable journeys together!"</marquee>
  <div class="carousel">
 <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="Miltes.jpg" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="FitIndia (1).jpg" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="pariksha.jpg" class="d-block w-100" alt="...">
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
</div>
    <footer>
      <a href="contact.html"><b>contact Us</b></a><br>
     Copy Right &copy;
    </footer>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>