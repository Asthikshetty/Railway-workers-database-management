<?php
// Check if the user is logged in (you may need to implement a session system)
// For demonstration purposes, let's assume there is a session variable named 'user_id'
session_start();

if (!isset($_SESSION['user_id'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: index.html");
    exit();
}

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "register";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve user information based on the user_id stored in the session
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = $user_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Fetch user data
    $row = $result->fetch_assoc();

    // Display user information in an edit form
    echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link rel="stylesheet" href="profile.css">
    <style>
        body {
            font-family: Verdana, sans-serif;
            font-weight: bold;
            background-image: url("plain-background-image.jpg");
            background-size: cover;
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <h2>Edit Profile</h2>
        <form action="update_profile.php" method="POST">
            <input type="hidden" name="user_id" value="' . $row['id'] . '">
            <label for="workinghours">Add Working Hour</label>
            <input type="text" id="workinghours" name="workinghours" value="' . $row['workinghours'] . '" required>

            <button type="submit">Update Hour</button>
        </form>
    </div>
    <script>
        // JavaScript code to enhance the page
        // For example, you can add animations or interactive elements here
    </script>
</body>
</html>';
} else {
    echo "User not found.";
}

// Close the database connection
$conn->close();
?>
